const prisma = require('../config/database');

// Lista de préstamos agrupados por doctor
const index = async (req, res) => {
  try {
    const [prestamos, doctores, conceptos] = await Promise.all([
      prisma.prestamo.findMany({
        include: {
          doctor: true,
          concepto: true,
          usuario: true,
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.doctor.findMany({
        where: { activo: true },
        orderBy: [{ apellido: 'asc' }, { nombre: 'asc' }],
      }),
      prisma.conceptoPrestamo.findMany({
        where: { activo: true },
        orderBy: { nombre: 'asc' },
      }),
    ]);

    // Agrupar por doctor y calcular totales
    const prestamosPorDoctor = {};
    prestamos.forEach(prestamo => {
      const doctorId = prestamo.doctorId;
      if (!prestamosPorDoctor[doctorId]) {
        prestamosPorDoctor[doctorId] = {
          doctor: prestamo.doctor,
          prestamos: [],
          totalDeuda: 0,
          totalPendiente: 0,
          totalPagado: 0,
        };
      }
      prestamosPorDoctor[doctorId].prestamos.push(prestamo);
      prestamosPorDoctor[doctorId].totalDeuda += parseFloat(prestamo.monto);
      if (prestamo.estatus === 'pendiente') {
        prestamosPorDoctor[doctorId].totalPendiente += parseFloat(prestamo.monto);
      } else {
        prestamosPorDoctor[doctorId].totalPagado += parseFloat(prestamo.monto);
      }
    });

    // Convertir a array y filtrar solo los que tienen deuda pendiente
    const doctoresConDeuda = Object.values(prestamosPorDoctor)
      .filter(item => item.totalPendiente > 0)
      .sort((a, b) => b.totalPendiente - a.totalPendiente);

    const { formatCurrency } = require('../utils/helpers');

    res.render('gastos/prestamos', {
      title: 'Préstamos al Personal',
      doctoresConDeuda,
      doctores,
      conceptos,
      formatCurrency,
    });
  } catch (error) {
    console.error('Error al cargar préstamos:', error);
    res.render('error', {
      title: 'Error',
      message: 'Error al cargar préstamos',
      error,
    });
  }
};

// Obtener detalle de préstamos de un doctor (API)
const detalle = async (req, res) => {
  try {
    const { doctorId } = req.params;

    const prestamos = await prisma.prestamo.findMany({
      where: { doctorId: parseInt(doctorId) },
      include: {
        doctor: true,
        concepto: true,
        usuario: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Calcular totales
    const totales = prestamos.reduce(
      (acc, prestamo) => {
        const monto = parseFloat(prestamo.monto);
        acc.totalDeuda += monto;
        if (prestamo.estatus === 'pendiente') {
          acc.totalPendiente += monto;
        } else {
          acc.totalPagado += monto;
        }
        return acc;
      },
      { totalDeuda: 0, totalPendiente: 0, totalPagado: 0 }
    );

    res.json({
      success: true,
      doctor: prestamos[0]?.doctor || null,
      prestamos,
      totales,
    });
  } catch (error) {
    console.error('Error al obtener detalle:', error);
    res.status(500).json({
      success: false,
      error: 'Error al obtener detalle de préstamos',
    });
  }
};

// Crear nuevo préstamo (API)
const store = async (req, res) => {
  try {
    const { doctorId, conceptoId, monto, notas } = req.body;

    // Validaciones
    if (!doctorId || !conceptoId || !monto) {
      return res.status(400).json({
        success: false,
        error: 'Doctor, concepto y monto son requeridos',
      });
    }

    if (parseFloat(monto) <= 0) {
      return res.status(400).json({
        success: false,
        error: 'El monto debe ser mayor a 0',
      });
    }

    // Verificar que el doctor existe
    const doctor = await prisma.doctor.findUnique({
      where: { id: parseInt(doctorId) },
    });

    if (!doctor) {
      return res.status(404).json({
        success: false,
        error: 'Doctor no encontrado',
      });
    }

    // Verificar que el concepto existe
    const concepto = await prisma.conceptoPrestamo.findUnique({
      where: { id: parseInt(conceptoId) },
    });

    if (!concepto) {
      return res.status(404).json({
        success: false,
        error: 'Concepto no encontrado',
      });
    }

    // Crear préstamo
    const prestamo = await prisma.prestamo.create({
      data: {
        doctorId: parseInt(doctorId),
        conceptoId: parseInt(conceptoId),
        monto: parseFloat(monto),
        notas: notas || null,
        estatus: 'pendiente',
        usuarioId: req.session.user?.id || null,
      },
      include: {
        doctor: true,
        concepto: true,
        usuario: true,
      },
    });

    res.json({
      success: true,
      prestamo,
      message: 'Préstamo registrado exitosamente',
    });
  } catch (error) {
    console.error('Error al crear préstamo:', error);
    res.status(500).json({
      success: false,
      error: 'Error al crear préstamo',
    });
  }
};

// Actualizar estatus de préstamo (API)
const updateEstatus = async (req, res) => {
  try {
    const { prestamoId } = req.params;
    const { estatus } = req.body;

    // Validaciones
    if (!estatus || !['pendiente', 'pagado'].includes(estatus)) {
      return res.status(400).json({
        success: false,
        error: 'Estatus inválido. Debe ser "pendiente" o "pagado"',
      });
    }

    // Actualizar préstamo
    const prestamo = await prisma.prestamo.update({
      where: { id: parseInt(prestamoId) },
      data: { estatus },
      include: {
        doctor: true,
        concepto: true,
        usuario: true,
      },
    });

    res.json({
      success: true,
      prestamo,
      message: 'Estatus actualizado exitosamente',
    });
  } catch (error) {
    console.error('Error al actualizar estatus:', error);
    res.status(500).json({
      success: false,
      error: 'Error al actualizar estatus',
    });
  }
};

// Lista de conceptos de préstamos
const indexConceptos = async (req, res) => {
  try {
    const conceptos = await prisma.conceptoPrestamo.findMany({
      orderBy: { nombre: 'asc' },
    });

    res.render('gastos/conceptos-prestamos', {
      title: 'Conceptos de Préstamos',
      conceptos,
    });
  } catch (error) {
    console.error('Error al cargar conceptos:', error);
    res.render('error', {
      title: 'Error',
      message: 'Error al cargar conceptos',
      error,
    });
  }
};

// Crear concepto (API)
const storeConcepto = async (req, res) => {
  try {
    const { nombre, descripcion } = req.body;

    if (!nombre || nombre.trim() === '') {
      return res.status(400).json({
        success: false,
        error: 'El nombre es requerido',
      });
    }

    const concepto = await prisma.conceptoPrestamo.create({
      data: {
        nombre: nombre.trim(),
        descripcion: descripcion?.trim() || null,
        activo: true,
      },
    });

    res.json({
      success: true,
      concepto,
      message: 'Concepto creado exitosamente',
    });
  } catch (error) {
    console.error('Error al crear concepto:', error);
    res.status(500).json({
      success: false,
      error: 'Error al crear concepto',
    });
  }
};

// Actualizar concepto (API)
const updateConcepto = async (req, res) => {
  try {
    const { conceptoId } = req.params;
    const { nombre, descripcion, activo } = req.body;

    if (!nombre || nombre.trim() === '') {
      return res.status(400).json({
        success: false,
        error: 'El nombre es requerido',
      });
    }

    const concepto = await prisma.conceptoPrestamo.update({
      where: { id: parseInt(conceptoId) },
      data: {
        nombre: nombre.trim(),
        descripcion: descripcion?.trim() || null,
        activo: activo === true || activo === 'true',
      },
    });

    res.json({
      success: true,
      concepto,
      message: 'Concepto actualizado exitosamente',
    });
  } catch (error) {
    console.error('Error al actualizar concepto:', error);
    res.status(500).json({
      success: false,
      error: 'Error al actualizar concepto',
    });
  }
};

module.exports = {
  index,
  detalle,
  store,
  updateEstatus,
  indexConceptos,
  storeConcepto,
  updateConcepto,
};

