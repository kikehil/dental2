-- AlterTable
ALTER TABLE `cortes_caja` MODIFY `hora` VARCHAR(191) NULL;
